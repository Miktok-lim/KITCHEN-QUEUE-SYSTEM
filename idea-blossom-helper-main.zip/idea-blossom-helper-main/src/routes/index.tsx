import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  findStudent,
  money,
  placeOrder,
  remaining,
  useCanteen,
  type MealCategory,
  type MenuItem,
  type Order,
} from "@/lib/canteen-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Campus Canteen Ordering — College Kitchen" },
      {
        name: "description",
        content:
          "Order today's canteen meals from the college kitchen, pay with your student meal plan, and collect your food by token number.",
      },
      { property: "og:title", content: "Campus Canteen Ordering — College Kitchen" },
      {
        property: "og:description",
        content: "Browse today's college canteen menu, order in seconds and pay with your meal plan.",
      },
    ],
  }),
  component: OrderKiosk,
});

const CATEGORIES: MealCategory[] = ["Breakfast", "Lunch", "Snacks", "Beverages"];

function OrderKiosk() {
  const menu = useCanteen((s) => s.menu);
  const [cart, setCart] = useState<Record<string, number>>({});
  const [customerName, setCustomerName] = useState("");
  const [studentId, setStudentId] = useState("");
  const [note, setNote] = useState("");
  const [placed, setPlaced] = useState<Order | null>(null);

  const student = studentId.trim() ? findStudent(studentId) : undefined;

  const lines = useMemo(
    () =>
      Object.entries(cart)
        .map(([itemId, qty]) => {
          const item = menu.find((m) => m.id === itemId);
          return item ? { itemId, name: item.name, price: item.price, qty } : null;
        })
        .filter((l): l is { itemId: string; name: string; price: number; qty: number } => !!l && l.qty > 0),
    [cart, menu],
  );

  const total = lines.reduce((sum, l) => sum + l.price * l.qty, 0);

  const change = (item: MenuItem, delta: number) => {
    setCart((c) => {
      const next = Math.max(0, (c[item.id] ?? 0) + delta);
      if (next > remaining(item)) {
        toast.error(`Only ${remaining(item)} portions left today.`);
        return c;
      }
      return { ...c, [item.id]: next };
    });
  };

  const submit = (payment: "wallet" | "cash") => {
    const result = placeOrder({ studentId, customerName, lines, payment, note });
    if (!result.ok) {
      toast.error(result.error);
      return;
    }
    setPlaced(result.order);
    setCart({});
    setNote("");
    setCustomerName("");
    toast.success(`Order placed — token #${result.order.token}`);
  };

  if (placed) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <p className="text-sm font-medium uppercase tracking-widest text-muted-foreground">Your token</p>
        <p className="font-display mt-2 text-8xl font-bold text-primary">#{placed.token}</p>
        <h1 className="mt-6 text-2xl font-semibold">
          Thanks{placed.customerName ? `, ${placed.customerName.split(" ")[0]}` : ""}!
        </h1>
        <p className="mt-2 text-muted-foreground">
          Watch the kitchen board and collect your tray from the counter when your token turns green.
        </p>
        <Card className="mt-8 text-left">
          <CardContent className="space-y-2 pt-6">
            {placed.lines.map((l) => (
              <div key={l.itemId} className="flex justify-between text-sm">
                <span>
                  {l.qty} × {l.name}
                </span>
                <span>{money(l.price * l.qty)}</span>
              </div>
            ))}
            <div className="flex justify-between border-t pt-2 font-semibold">
              <span>Total ({placed.payment === "wallet" ? "meal plan" : "cash at counter"})</span>
              <span>{money(placed.total)}</span>
            </div>
          </CardContent>
        </Card>
        <Button className="mt-8" size="lg" onClick={() => setPlaced(null)}>
          Place another order
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <header className="mb-8">
        <Badge variant="secondary" className="mb-3">
          Serving today · {new Date().toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" })}
        </Badge>
        <h1 className="text-3xl font-bold sm:text-4xl">Today&apos;s canteen menu</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          Pick your meal and order — no login or ID needed. Pay cash at the counter, or use a meal plan if you have one.
        </p>
      </header>

      <div className="grid gap-8 lg:grid-cols-[1fr_20rem]">
        <div className="space-y-10">
          {CATEGORIES.map((category) => {
            const items = menu.filter((m) => m.category === category);
            if (items.length === 0) return null;
            return (
              <section key={category}>
                <h2 className="mb-3 text-lg font-semibold">{category}</h2>
                <div className="grid gap-3 sm:grid-cols-2">
                  {items.map((item) => {
                    const left = remaining(item);
                    const soldOut = !item.available || left === 0;
                    return (
                      <Card key={item.id} className={soldOut ? "opacity-60" : ""}>
                        <CardContent className="flex h-full flex-col gap-3 pt-6">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <h3 className="text-base font-semibold">{item.name}</h3>
                              <p className="text-sm text-muted-foreground">{item.description}</p>
                            </div>
                            <span
                              className={`mt-1 size-3 shrink-0 rounded-full ${item.veg ? "bg-primary" : "bg-destructive"}`}
                              aria-label={item.veg ? "Vegetarian" : "Non-vegetarian"}
                            />
                          </div>
                          <div className="mt-auto flex items-center justify-between">
                            <div>
                              <p className="font-semibold">{money(item.price)}</p>
                              <p className="text-xs text-muted-foreground">
                                {soldOut ? "Sold out" : `${left} portions left`}
                              </p>
                            </div>
                            {soldOut ? null : (
                              <div className="flex items-center gap-2">
                                <Button
                                  size="icon"
                                  variant="outline"
                                  onClick={() => change(item, -1)}
                                  disabled={!cart[item.id]}
                                  aria-label={`Remove one ${item.name}`}
                                >
                                  −
                                </Button>
                                <span className="w-6 text-center tabular-nums">{cart[item.id] ?? 0}</span>
                                <Button size="icon" onClick={() => change(item, 1)} aria-label={`Add one ${item.name}`}>
                                  +
                                </Button>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>

        <aside className="lg:sticky lg:top-6 lg:h-fit">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <h2 className="text-lg font-semibold">Your tray</h2>
              {lines.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nothing added yet.</p>
              ) : (
                <div className="space-y-1">
                  {lines.map((l) => (
                    <div key={l.itemId} className="flex justify-between text-sm">
                      <span>
                        {l.qty} × {l.name}
                      </span>
                      <span>{money(l.price * l.qty)}</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex justify-between border-t pt-3 font-semibold">
                <span>Total</span>
                <span>{money(total)}</span>
              </div>

              <div className="space-y-2">
                <Label htmlFor="customerName">Name (optional)</Label>
                <Input
                  id="customerName"
                  placeholder="So we can call you out"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="studentId">Meal plan ID (optional)</Label>
                <Input
                  id="studentId"
                  placeholder="Only if paying from a meal plan"
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value.toUpperCase())}
                />
                {student ? (
                  <p className="text-xs text-muted-foreground">
                    {student.name} · {student.program} · balance {money(student.balance)}
                  </p>
                ) : studentId.trim() ? (
                  <p className="text-xs text-destructive">No meal plan found for that ID.</p>
                ) : null}
              </div>

              <div className="space-y-2">
                <Label htmlFor="note">Note for the kitchen (optional)</Label>
                <Textarea
                  id="note"
                  rows={2}
                  placeholder="Less spicy, no onion…"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />
              </div>

              <div className="grid gap-2">
                <Button size="lg" disabled={!lines.length} onClick={() => submit("cash")}>
                  Place order · pay at counter
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  disabled={!lines.length || !student}
                  onClick={() => submit("wallet")}
                >
                  Pay with meal plan
                </Button>
              </div>
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}
