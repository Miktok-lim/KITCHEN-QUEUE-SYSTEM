import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  addMenuItem,
  money,
  removeMenuItem,
  updateMenuItem,
  useCanteen,
  type MealCategory,
} from "@/lib/canteen-store";

export const Route = createFileRoute("/planner")({
  head: () => ({
    meta: [
      { title: "Daily Menu Planner — College Kitchen" },
      {
        name: "description",
        content: "Plan the college canteen menu for the day: set dishes, prices and how many portions the kitchen prepares.",
      },
      { property: "og:title", content: "Daily Menu Planner — College Kitchen" },
      { property: "og:description", content: "Set today's canteen dishes, prices and portion counts." },
    ],
  }),
  component: Planner,
});

const CATEGORIES: MealCategory[] = ["Breakfast", "Lunch", "Snacks", "Beverages"];

function Planner() {
  const menu = useCanteen((s) => s.menu);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [category, setCategory] = useState<MealCategory>("Lunch");
  const [veg, setVeg] = useState(true);

  const add = () => {
    if (!name.trim()) {
      toast.error("Give the dish a name.");
      return;
    }
    const p = Number(price);
    const q = Number(quantity);
    if (!Number.isFinite(p) || p <= 0) {
      toast.error("Enter a valid price.");
      return;
    }
    if (!Number.isFinite(q) || q <= 0) {
      toast.error("Enter how many portions you'll prepare.");
      return;
    }
    addMenuItem({
      name: name.trim(),
      description: description.trim() || "Prepared fresh today",
      price: p,
      quantity: q,
      category,
      available: true,
      veg,
    });
    setName("");
    setDescription("");
    setPrice("");
    setQuantity("");
    toast.success("Added to today's menu.");
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">Daily menu planner</h1>
        <p className="mt-2 text-muted-foreground">
          Decide what the kitchen serves today and how many portions are prepared. Students only see available dishes.
        </p>
      </header>

      <Card className="mb-8">
        <CardContent className="pt-6">
          <h2 className="mb-4 text-lg font-semibold">Add a dish</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Dish name</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Rajma Chawal" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="desc">Description</Label>
              <Input
                id="desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Kidney beans curry with steamed rice"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">Price (Rs)</Label>
              <Input id="price" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="qty">Portions prepared</Label>
              <Input id="qty" inputMode="numeric" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Meal time</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as MealCategory)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end gap-3">
              <div className="flex items-center gap-2">
                <Switch id="veg" checked={veg} onCheckedChange={setVeg} />
                <Label htmlFor="veg">Vegetarian</Label>
              </div>
              <Button className="ml-auto" onClick={add}>
                Add dish
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {menu.map((item) => (
          <Card key={item.id}>
            <CardContent className="flex flex-wrap items-center gap-4 pt-6">
              <div className="min-w-48 flex-1">
                <p className="font-semibold">
                  {item.name} <span className="text-sm font-normal text-muted-foreground">· {item.category}</span>
                </p>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
              <div className="w-24">
                <Label className="text-xs text-muted-foreground">Price</Label>
                <Input
                  value={item.price}
                  inputMode="numeric"
                  onChange={(e) => updateMenuItem(item.id, { price: Number(e.target.value) || 0 })}
                />
              </div>
              <div className="w-28">
                <Label className="text-xs text-muted-foreground">Portions</Label>
                <Input
                  value={item.quantity}
                  inputMode="numeric"
                  onChange={(e) => updateMenuItem(item.id, { quantity: Number(e.target.value) || 0 })}
                />
              </div>
              <div className="text-sm text-muted-foreground">
                <p>Sold: {item.sold}</p>
                <p>Revenue: {money(item.sold * item.price)}</p>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={item.available}
                  onCheckedChange={(v) => updateMenuItem(item.id, { available: v })}
                  aria-label={`Serving ${item.name}`}
                />
                <span className="text-sm">{item.available ? "Serving" : "Off menu"}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => removeMenuItem(item.id)}>
                Remove
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
