import { createFileRoute } from "@tanstack/react-router";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { money, setOrderStatus, useCanteen, type Order, type OrderStatus } from "@/lib/canteen-store";

export const Route = createFileRoute("/kitchen")({
  head: () => ({
    meta: [
      { title: "Kitchen Board — College Kitchen" },
      {
        name: "description",
        content: "Live order queue for college kitchen staff: track student orders from queued to preparing, ready and served.",
      },
      { property: "og:title", content: "Kitchen Board — College Kitchen" },
      { property: "og:description", content: "Live student order queue for the college kitchen staff." },
    ],
  }),
  component: KitchenBoard,
});

const COLUMNS: Array<{ status: OrderStatus; title: string; next?: OrderStatus; action?: string }> = [
  { status: "queued", title: "New orders", next: "preparing", action: "Start cooking" },
  { status: "preparing", title: "Preparing", next: "ready", action: "Mark ready" },
  { status: "ready", title: "Ready for pickup", next: "served", action: "Mark served" },
  { status: "served", title: "Served" },
];

function KitchenBoard() {
  const orders = useCanteen((s) => s.orders);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">Kitchen board</h1>
        <p className="mt-2 text-muted-foreground">
          {orders.filter((o) => o.status !== "served").length} orders in the queue right now.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-4">
        {COLUMNS.map((col) => {
          const list = orders.filter((o) => o.status === col.status);
          return (
            <section key={col.status} className="rounded-xl bg-secondary/60 p-3">
              <div className="mb-3 flex items-center justify-between px-1">
                <h2 className="text-sm font-semibold uppercase tracking-wide">{col.title}</h2>
                <Badge variant="outline">{list.length}</Badge>
              </div>
              <div className="space-y-3">
                {list.length === 0 ? (
                  <p className="px-1 pb-2 text-sm text-muted-foreground">Nothing here.</p>
                ) : (
                  list.map((order) => <OrderCard key={order.id} order={order} next={col.next} action={col.action} />)
                )}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function OrderCard({ order, next, action }: { order: Order; next?: OrderStatus | undefined; action?: string | undefined }) {
  return (
    <Card>
      <CardContent className="space-y-3 pt-5">
        <div className="flex items-baseline justify-between">
          <span className="font-display text-2xl font-bold text-primary">#{order.token}</span>
          <span className="text-xs text-muted-foreground">
            {new Date(order.placedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>
        <p className="text-sm font-medium">
          {order.customerName ?? "Walk-in"}
          {order.studentId ? <span className="text-muted-foreground"> · {order.studentId}</span> : null}
        </p>
        <ul className="space-y-1 text-sm">
          {order.lines.map((l) => (
            <li key={l.itemId}>
              {l.qty} × {l.name}
            </li>
          ))}
        </ul>
        {order.note ? <p className="rounded-md bg-accent/30 p-2 text-xs">Note: {order.note}</p> : null}
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{money(order.total)}</span>
          <span>{order.payment === "wallet" ? "Meal plan" : "Cash"}</span>
        </div>
        {next && action ? (
          <Button className="w-full" size="sm" onClick={() => setOrderStatus(order.id, next)}>
            {action}
          </Button>
        ) : null}
      </CardContent>
    </Card>
  );
}
