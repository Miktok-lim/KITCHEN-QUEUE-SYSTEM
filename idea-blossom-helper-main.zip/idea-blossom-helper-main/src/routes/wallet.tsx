import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { money, topUp, useCanteen } from "@/lib/canteen-store";

export const Route = createFileRoute("/wallet")({
  head: () => ({
    meta: [
      { title: "Student Meal Plan — College Kitchen" },
      {
        name: "description",
        content: "Check a student's prepaid meal plan balance, top it up at the college office and review canteen spending.",
      },
      { property: "og:title", content: "Student Meal Plan — College Kitchen" },
      { property: "og:description", content: "Check and top up prepaid student meal plan balances." },
    ],
  }),
  component: WalletPage,
});

function WalletPage() {
  const students = useCanteen((s) => s.students);
  const transactions = useCanteen((s) => s.transactions);
  const [selected, setSelected] = useState<string | null>(null);
  const [amount, setAmount] = useState("");

  const student = students.find((s) => s.id === selected);
  const history = transactions.filter((t) => t.studentId === selected);

  const doTopUp = () => {
    if (!student) return;
    const result = topUp(student.id, Number(amount));
    if (!result.ok) {
      toast.error(result.error ?? "Top-up failed.");
      return;
    }
    setAmount("");
    toast.success(`Added ${money(Number(amount))} to ${student.name}'s meal plan.`);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">Student meal plans</h1>
        <p className="mt-2 text-muted-foreground">
          Prepaid canteen credit for students. Top up at the college office and spend it at the counter.
        </p>
      </header>

      <div className="grid gap-6 md:grid-cols-[18rem_1fr]">
        <div className="space-y-2">
          {students.map((s) => (
            <button
              key={s.id}
              onClick={() => setSelected(s.id)}
              className={`w-full rounded-lg border p-3 text-left transition-colors ${
                selected === s.id ? "border-primary bg-secondary" : "hover:bg-secondary/60"
              }`}
            >
              <p className="font-medium">{s.name}</p>
              <p className="text-xs text-muted-foreground">
                {s.id} · {s.program}
              </p>
              <p className="mt-1 text-sm font-semibold text-primary">{money(s.balance)}</p>
            </button>
          ))}
        </div>

        <Card>
          <CardContent className="pt-6">
            {!student ? (
              <p className="text-sm text-muted-foreground">Select a student to view their meal plan.</p>
            ) : (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-semibold">{student.name}</h2>
                  <p className="text-sm text-muted-foreground">
                    {student.id} · {student.program}
                  </p>
                  <p className="font-display mt-3 text-4xl font-bold text-primary">{money(student.balance)}</p>
                </div>

                <div className="flex flex-wrap items-end gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Top-up amount (Rs)</Label>
                    <Input
                      id="amount"
                      inputMode="numeric"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-40"
                    />
                  </div>
                  <Button onClick={doTopUp}>Add credit</Button>
                  {[200, 500, 1000].map((v) => (
                    <Button key={v} variant="outline" size="sm" onClick={() => setAmount(String(v))}>
                      {money(v)}
                    </Button>
                  ))}
                </div>

                <div>
                  <h3 className="mb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                    Recent activity
                  </h3>
                  {history.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No meal plan activity yet.</p>
                  ) : (
                    <ul className="divide-y">
                      {history.slice(0, 12).map((t) => (
                        <li key={t.id} className="flex justify-between py-2 text-sm">
                          <span>
                            {t.label}
                            <span className="ml-2 text-xs text-muted-foreground">
                              {new Date(t.at).toLocaleString([], {
                                day: "numeric",
                                month: "short",
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </span>
                          <span className={t.amount < 0 ? "text-muted-foreground" : "font-medium text-primary"}>
                            {t.amount < 0 ? "−" : "+"}
                            {money(Math.abs(t.amount))}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
