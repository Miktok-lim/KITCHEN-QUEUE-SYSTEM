import { useSyncExternalStore } from "react";

export type MealCategory = "Breakfast" | "Lunch" | "Snacks" | "Beverages";

export type MenuItem = {
  id: string;
  name: string;
  description: string;
  price: number;
  category: MealCategory;
  available: boolean;
  /** Portions prepared for today */
  quantity: number;
  /** Portions already ordered today */
  sold: number;
  veg: boolean;
};

export type OrderStatus = "queued" | "preparing" | "ready" | "served";

export type OrderLine = { itemId: string; name: string; price: number; qty: number };

export type Order = {
  id: string;
  token: number;
  studentId?: string | undefined;
  customerName?: string | undefined;
  lines: OrderLine[];
  total: number;
  payment: "wallet" | "cash";
  status: OrderStatus;
  placedAt: number;
  note?: string | undefined;
};

export type Student = {
  id: string;
  name: string;
  program: string;
  balance: number;
};

export type WalletTx = {
  id: string;
  studentId: string;
  amount: number; // positive = top-up, negative = spend
  label: string;
  at: number;
};

export type CanteenState = {
  menu: MenuItem[];
  orders: Order[];
  students: Student[];
  transactions: WalletTx[];
  nextToken: number;
  menuDate: string;
};

const STORAGE_KEY = "college-canteen-state-v1";

export const todayKey = () => new Date().toISOString().slice(0, 10);

const uid = () => Math.random().toString(36).slice(2, 10);

function seedMenu(): MenuItem[] {
  const base: Array<Omit<MenuItem, "id" | "sold">> = [
    { name: "Veg Thali", description: "Rice, dal, seasonal vegetable, pickle", price: 90, category: "Lunch", available: true, quantity: 120, veg: true },
    { name: "Chicken Thali", description: "Rice, dal, chicken curry, salad", price: 150, category: "Lunch", available: true, quantity: 80, veg: false },
    { name: "Veg Momo (10 pcs)", description: "Steamed dumplings with tomato achar", price: 100, category: "Snacks", available: true, quantity: 60, veg: true },
    { name: "Chowmein", description: "Stir-fried noodles with vegetables", price: 80, category: "Snacks", available: true, quantity: 70, veg: true },
    { name: "Aloo Paratha", description: "Two parathas with curd", price: 70, category: "Breakfast", available: true, quantity: 50, veg: true },
    { name: "Boiled Egg Sandwich", description: "Whole wheat bread, egg, greens", price: 60, category: "Breakfast", available: true, quantity: 40, veg: false },
    { name: "Milk Tea", description: "Freshly brewed", price: 25, category: "Beverages", available: true, quantity: 200, veg: true },
    { name: "Lemon Soda", description: "Chilled, lightly salted", price: 40, category: "Beverages", available: true, quantity: 90, veg: true },
  ];
  return base.map((m) => ({ ...m, id: uid(), sold: 0 }));
}

function seedStudents(): Student[] {
  return [
    { id: "CS2201", name: "Aayush Khadka", program: "BSc CSIT", balance: 1250 },
    { id: "CS2214", name: "Prerana Sharma", program: "BSc CSIT", balance: 640 },
    { id: "BBA2109", name: "Nirajan Thapa", program: "BBA", balance: 310 },
    { id: "ENG2305", name: "Sita Gurung", program: "BE Civil", balance: 980 },
    { id: "MGT2402", name: "Bipin Rai", program: "BBS", balance: 150 },
  ];
}

function seedState(): CanteenState {
  return {
    menu: seedMenu(),
    orders: [],
    students: seedStudents(),
    transactions: [],
    nextToken: 101,
    menuDate: todayKey(),
  };
}

let state: CanteenState = seedState();
let hydrated = false;
const listeners = new Set<() => void>();

function persist() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* ignore quota errors */
  }
}

function emit() {
  listeners.forEach((l) => l());
}

function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as CanteenState;
      if (parsed && Array.isArray(parsed.menu)) state = parsed;
    }
  } catch {
    /* ignore corrupt storage */
  }
  // New day: reset the served counters and the order board.
  if (state.menuDate !== todayKey()) {
    state = {
      ...state,
      menuDate: todayKey(),
      orders: [],
      nextToken: 101,
      menu: state.menu.map((m) => ({ ...m, sold: 0 })),
    };
    persist();
  }
  emit();
}

function setState(updater: (s: CanteenState) => CanteenState) {
  state = updater(state);
  persist();
  emit();
}

export function useCanteen<T>(selector: (s: CanteenState) => T): T {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      hydrate();
      return () => listeners.delete(cb);
    },
    () => selector(state),
    () => selector(state),
  );
}

export const remaining = (item: MenuItem) => Math.max(0, item.quantity - item.sold);

/* ---------- menu planner actions ---------- */

export function addMenuItem(item: Omit<MenuItem, "id" | "sold">) {
  setState((s) => ({ ...s, menu: [...s.menu, { ...item, id: uid(), sold: 0 }] }));
}

export function updateMenuItem(id: string, patch: Partial<MenuItem>) {
  setState((s) => ({
    ...s,
    menu: s.menu.map((m) => (m.id === id ? { ...m, ...patch } : m)),
  }));
}

export function removeMenuItem(id: string) {
  setState((s) => ({ ...s, menu: s.menu.filter((m) => m.id !== id) }));
}

/* ---------- ordering ---------- */

export type PlaceOrderInput = {
  studentId?: string;
  customerName?: string;
  lines: OrderLine[];
  payment: "wallet" | "cash";
  note?: string;
};

export function placeOrder(input: PlaceOrderInput): { ok: true; order: Order } | { ok: false; error: string } {
  const student = input.studentId?.trim()
    ? state.students.find((st) => st.id.toLowerCase() === input.studentId!.trim().toLowerCase())
    : undefined;
  if (input.lines.length === 0) return { ok: false, error: "Your tray is empty." };

  const total = input.lines.reduce((sum, l) => sum + l.price * l.qty, 0);
  if (input.payment === "wallet") {
    if (!student) return { ok: false, error: "Enter a valid meal plan ID to pay from a meal plan." };
    if (student.balance < total) {
      return { ok: false, error: `Meal plan balance is short by Rs ${total - student.balance}.` };
    }
  }

  for (const line of input.lines) {
    const item = state.menu.find((m) => m.id === line.itemId);
    if (!item || !item.available) return { ok: false, error: `${line.name} is no longer being served.` };
    if (remaining(item) < line.qty) return { ok: false, error: `Only ${remaining(item)} portions of ${line.name} left.` };
  }

  const order: Order = {
    id: uid(),
    token: state.nextToken,
    studentId: student?.id,
    customerName: input.customerName?.trim() || student?.name || undefined,
    lines: input.lines,
    total,
    payment: input.payment,
    status: "queued",
    placedAt: Date.now(),
    note: input.note?.trim() || undefined,
  };

  setState((s) => ({
    ...s,
    nextToken: s.nextToken + 1,
    orders: [order, ...s.orders],
    menu: s.menu.map((m) => {
      const line = input.lines.find((l) => l.itemId === m.id);
      return line ? { ...m, sold: m.sold + line.qty } : m;
    }),
    students: s.students.map((st) =>
      student && st.id === student.id && input.payment === "wallet" ? { ...st, balance: st.balance - total } : st,
    ),
    transactions:
      input.payment === "wallet" && student
        ? [
            { id: uid(), studentId: student.id, amount: -total, label: `Order #${order.token}`, at: Date.now() },
            ...s.transactions,
          ]
        : s.transactions,
  }));

  return { ok: true, order };
}

export function setOrderStatus(id: string, status: OrderStatus) {
  setState((s) => ({ ...s, orders: s.orders.map((o) => (o.id === id ? { ...o, status } : o)) }));
}

/* ---------- wallet ---------- */

export function findStudent(id: string): Student | undefined {
  return state.students.find((s) => s.id.toLowerCase() === id.trim().toLowerCase());
}

export function topUp(studentId: string, amount: number): { ok: boolean; error?: string } {
  const student = findStudent(studentId);
  if (!student) return { ok: false, error: "Student ID not found." };
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, error: "Enter an amount greater than zero." };
  setState((s) => ({
    ...s,
    students: s.students.map((st) => (st.id === student.id ? { ...st, balance: st.balance + amount } : st)),
    transactions: [
      { id: uid(), studentId: student.id, amount, label: "Meal plan top-up", at: Date.now() },
      ...s.transactions,
    ],
  }));
  return { ok: true };
}

export const money = (n: number) => `Rs ${n.toLocaleString("en-IN")}`;
